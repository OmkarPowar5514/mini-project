import { LightningElement } from 'lwc';
import fetchGSTDetails from '@salesforce/apex/GSTDetailRestApiHandler.fetchGSTDetails'
import addGstDetail from '@salesforce/apex/InsertGstDetailHandler.addGstDetail'
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
const reg = '^([0][1-9]|[1-2][0-9]|[3][0-7])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$'
export default class GstDetailCmp extends LightningElement {
    
    gstNumber
    gstDetail = []
    name
    address
    valid
    error
    value = false
    rowOffset = 0
    columns = [
        { label: 'Name', fieldName: 'name' },
        { label: 'GstNumber', fieldName: 'gstNumber' },
        { label: 'Address', fieldName: 'address' },
        { label: 'Status', fieldName: 'valid' },
        { label: 'Pincode', fieldName: 'pinCode' },
    ]

    checkGstNumber(event){
        if(event.target.value){
            if(event.target.value.match(reg)){
                this.gstNumber = event.target.value
                const gstNumberIsValid = new ShowToastEvent({
                    title: 'GST Number is Valid',
                    variant : 'Success'
                });
                this.dispatchEvent(gstNumberIsValid);
            }else{
                this.value=false
                this.gstNumber = null
                const gstNumberIsInvalid = new ShowToastEvent({
                    title: 'GST Number is Invalid',
                    variant : 'destructive'
                });
                this.dispatchEvent(gstNumberIsInvalid);
            }
        }else{
            this.value = false
        }
    }

    fetchGstDetail(){
        if(this.gstNumber.match(reg)){
            fetchGSTDetails({gstNumber:this.gstNumber}).then(result=>{
                this.value = true
                if(result.name){
                    this.gstDetail = [{
                        name: result.name,
                        gstNumber: result.gstNumber,
                        address: result.address,
                        valid: result.valid, 
                        pinCode: result.pinCode 
                    }];
                    const recordFound = new ShowToastEvent({
                        title: 'GST Detial Found',
                        variant : 'Success'
                    });
                    this.dispatchEvent(recordFound);
                }else{
                    this.gstDetail = null
                    this.value=false
                    const recordNotFound = new ShowToastEvent({
                        title: 'GST Detail Not Found',
                        variant : 'destructive'
                    });
                    this.dispatchEvent(recordNotFound);
                }
            }).catch(error=>{
                this.error = error.body.message 
                const errorMsg = new ShowToastEvent({
                    title: 'GST Detail Found',
                    variant : 'destructive'
                });
                this.dispatchEvent(errorMsg);
            })
        }else{
            this.value = false
        }
    }

    saveToObject(){
        if(this.gstDetail){
            const gstMap = {
                'name': this.gstDetail[0].name,
                'gstNumber': this.gstDetail[0].gstNumber,
                'address': this.gstDetail[0].address,
                'valid': this.gstDetail[0].valid,
                'pinCode': this.gstDetail[0].pinCode
            };
            addGstDetail({gstMap:gstMap,gstList:gstMap}).then(result=>{
                if(result != ''){
                    const resultEvent = new ShowToastEvent({
                        title: result,
                        variant : 'Success'
                    });
                    this.dispatchEvent(resultEvent);
                }
            })
        }
    }
}