const express = require('express');
const { registerUser, userlogin } = require('../controllers/userloginController');
const router = express.Router();

//Route to create user
router.post('/register', registerUser);

//Route to check userlogin
router.get('/login', userlogin);

module.exports = router;