const express = require('express');
const { createAccount, getBalance } = require('../controllers/accountController');
const router = express.Router();

// Route to create a bank account
router.post('/create', createAccount);

// Route to get the balance of a bank account by account ID
router.get('/:accountId', getBalance);

module.exports = router;
