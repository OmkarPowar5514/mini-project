const express = require('express');
const { depositTransaction, withdrawalTransaction } = require('../controllers/transactionController');
const router = express.Router();

// Route to make a deposit transaction (credit)
router.post('/deposit', depositTransaction);

// Route to make a withdrawal transaction (debit)
router.post('/withdrawal', withdrawalTransaction);

module.exports = router;
