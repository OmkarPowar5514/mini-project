const express = require('express');
const dotenv = require('dotenv');
const morgan = require("morgan");
const userloginRoutes = require('./routes/userloginRoutes');
const accountRoutes = require('./routes/accountRoutes');
const transactionRoutes = require('./routes/transactionRoutes');

dotenv.config();

const app = express();
app.use(express.json());
app.use(morgan("dev"));

app.use('/api/userlogin', userloginRoutes);
app.use('/api/accounts', accountRoutes);
app.use('/api/transactions', transactionRoutes);

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
