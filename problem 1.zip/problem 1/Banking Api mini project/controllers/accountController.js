const db = require('../config/db');

// Create a bank account
const createAccount = async (req, res) => {
    const { userloginId, bank_account_number, ifsc_code } = req.body;

    if (!bank_account_number || !ifsc_code) {
        return res.status(400).json({ success: false, message: 'Bank account number and IFSC code are required' });
    }

    try {
        //Insert account Detial
        const data = await db.query('INSERT INTO accounts (userlogin_id, bank_account_number, ifsc_code) VALUES (?, ?, ?)',
            [userloginId, bank_account_number, ifsc_code]
        );
        if(!data){
            return res.status(400).send({ success : false, message : 'Error while inserting account detial' })
        }
        res.status(201).json({ success: true, message: 'Account created successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error while creating account' });
    }
};

// Get account balance
const getBalance = async (req, res) => {
    const accountId = req.params.accountId;

    try {
        //Fetch account for balance
        const [rows] = await db.query('SELECT balance FROM accounts WHERE id = ?', [accountId]);
        if (rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Account not found' });
        }

        res.status(200).json({ success: true, balance: rows[0].balance });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error retrieving balance' });
    }
};

module.exports = { createAccount, getBalance };
