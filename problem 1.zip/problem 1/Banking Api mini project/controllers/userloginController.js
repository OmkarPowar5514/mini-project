const db = require('../config/db');

// Registering user
const registerUser = async (req, res) => {
    try {
        const { username, password } = req.body;

        // Check if username exists
        const [rows] = await db.query('SELECT * FROM userlogin WHERE username = ?', [username]);
        if (rows.length > 0) {
            return res.status(400).json({ success: false, message: 'Username already exists' });
        }

        // Insert new userlogin
        const data = await db.query('INSERT INTO userlogin (username, password) VALUES (?, ?)', [username, password]);
        if(!data){
            return res.status(400).send({ success : false, message : 'Error while inserting user detial' })
        }
        return res.status(201).json({ success: true, message: 'user registered successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error while registering user' });
    }
};

//Check user is logged In or not
const userlogin = async (req, res) => {
    try {
        const { username, password } = req.body;

        //Check if user is exists
        const [rows] = await db.query('SELECT * FROM userlogin WHERE username = ?', [username]);
        if (rows.length === 0) {
            return res.status(400).json({ success: false, message: 'Username is incorrect' });
        }

        const user = rows[0];
        //Compare the password with existing
        const isMatch = (password === user.password);

        if (!isMatch) {
            return res.status(400).json({ success: false, message: 'Password is incorrect' });
        }

        return res.status(200).json({ success: true, message: 'Login successful', userId: user.id });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error while logging in' });
    }
};

module.exports = { registerUser, userlogin };
