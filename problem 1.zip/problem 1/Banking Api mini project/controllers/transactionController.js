const db = require('../config/db');

// Deposit transaction
const depositTransaction = async (req, res) => {
    const { accountId, amount } = req.body;

    if (!amount || amount <= 0) {
        return res.status(400).json({ success: false, message: 'Invalid amount' });
    }

    try {
        //Update account balance 
        //Add account balance with existing balance
        const updateData = await db.query('UPDATE accounts SET balance = balance + ? WHERE id = ?', [amount, accountId]);
        if(!updateData){
            return res.status(400).send({ success : false, message : 'Error while updating account balance' })
        }

        //Insert transaction details
        const insertData = await db.query('INSERT INTO transactions (account_id, type, amount) VALUES (?, ?, ?)', [accountId, 'CREDIT', amount]);
        if(!insertData){
            return res.status(400).send({ success : false, message : 'Error while inserting transaction detial' })
        }
        
        res.status(200).json({ success: true, message: 'Deposit successful' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error during deposit' });
    }
};

// Withdrawal transaction
const withdrawalTransaction = async (req, res) => {
    const { accountId, amount } = req.body;

    if (!amount || amount <= 0) {
        return res.status(400).json({ success: false, message: 'Invalid amount' });
    }

    try {
        const [accountRows] = await db.query('SELECT balance, daily_withdrawal_limit FROM accounts WHERE id = ?', [accountId]);

        if (accountRows.length === 0) {
            return res.status(404).json({ success: false, message: 'Account not found' });
        }

        const account = accountRows[0];

        if (account.balance < amount) {
            return res.status(400).json({ success: false, message: 'Insufficient balance' });
        }

        if (amount > account.daily_withdrawal_limit) {
            return res.status(400).json({ success: false, message: `Withdrawal limit exceeded. Max limit is ${account.daily_withdrawal_limit}` });
        }

        //Update account balance 
        //Subtract account balance with existing balance
        const updateData = await db.query('UPDATE accounts SET balance = balance - ? WHERE id = ?', [amount, accountId]);
        if(!updateData){
            return res.status(400).send({ success : false, message : 'Error while updating account detial' })
        }


        const insertData = await db.query('INSERT INTO transactions (account_id, type, amount) VALUES (?, ?, ?)', [accountId, 'DEBIT', amount]);
        if(!insertData){
            return res.status(400).send({ success : false, message : 'Error while inserting transaction detial' })
        }

        res.status(200).json({ success: true, message: 'Withdrawal successful' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error during withdrawal' });
    }
};

module.exports = { depositTransaction, withdrawalTransaction };
